import chalk from 'chalk';

export async function updateCommand(_packageName?: string, _options?: { all?: boolean }) {
  console.log(chalk.yellow('\n⚠️  Update functionality coming soon!\n'));
  console.log(chalk.gray('This feature will allow you to update installed MCP servers.'));
  console.log('');
}
